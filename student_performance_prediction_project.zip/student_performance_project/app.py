import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

st.set_page_config(
    page_title="Student Performance Predictor",
    page_icon="🎓",
    layout="centered"
)

st.title("🎓 Student Performance Predictor")
st.write(
    "Estimate exam marks using study hours, attendance, "
    "and previous exam marks."
)

@st.cache_resource
def train_model():
    # Demonstration data only; not real student records.
    np.random.seed(42)
    n = 200

    study_hours = np.random.uniform(0, 8, n)
    attendance = np.random.uniform(40, 100, n)
    previous_marks = np.random.uniform(20, 95, n)
    noise = np.random.normal(0, 5, n)

    final_marks = (
        0.30 * previous_marks
        + 4 * study_hours
        + 0.20 * (attendance - 50)
        + noise
    )
    final_marks = np.clip(final_marks, 0, 100)

    df = pd.DataFrame({
        "study_hours": study_hours,
        "attendance": attendance,
        "previous_marks": previous_marks,
        "final_marks": final_marks,
    })

    X = df[["study_hours", "attendance", "previous_marks"]]
    y = df["final_marks"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)
    mae = mean_absolute_error(y_test, model.predict(X_test))
    return model, mae

model, mae = train_model()

st.subheader("Enter Student Details")
study_hours = st.number_input(
    "Study hours per day", min_value=0.0, max_value=12.0,
    value=5.0, step=0.5
)
attendance = st.slider(
    "Attendance percentage", min_value=0, max_value=100, value=75
)
previous_marks = st.number_input(
    "Previous exam marks (out of 100)", min_value=0.0,
    max_value=100.0, value=60.0, step=1.0
)

if st.button("Predict Marks", type="primary"):
    student = pd.DataFrame([{
        "study_hours": study_hours,
        "attendance": attendance,
        "previous_marks": previous_marks,
    }])
    prediction = float(np.clip(model.predict(student)[0], 0, 100))

    st.subheader("Prediction Result")
    st.metric("Estimated Final Marks", f"{prediction:.2f} / 100")
    st.progress(int(round(prediction)))
    st.info(
        "This is an estimate from a model trained on simulated data. "
        "It is not a guaranteed exam result."
    )

with st.expander("About this machine learning model"):
    st.write("Algorithm: Linear Regression")
    st.write("Input features: Study hours, attendance, previous marks")
    st.write("Training records: 160")
    st.write("Testing records: 40")
    st.write(f"Test MAE on simulated data: {mae:.2f} marks")
    st.caption(
        "For a stronger project, validate the model on a suitable real dataset."
    )
