# Student Performance Prediction using Machine Learning

A beginner-friendly college mini-project built with Python, scikit-learn, and Streamlit.

## Files
- `app.py`: Streamlit website and machine-learning model
- `requirements.txt`: Required Python packages

## Run on a computer
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Start the app:
   `streamlit run app.py`
5. Open the local URL printed in the terminal (usually http://localhost:8501).

## Important note
The app currently trains on simulated demonstration data, not real student records.
Predictions are for educational demonstration and should not be treated as reliable
academic assessments. For a stronger project, use a suitable real dataset and evaluate
the model on unseen records.

## Online deployment
You can push these files to a GitHub repository and deploy them with Streamlit Community Cloud.
